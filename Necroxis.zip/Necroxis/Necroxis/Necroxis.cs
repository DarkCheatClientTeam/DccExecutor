﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ForlornApi;

namespace Necroxis
{
    public partial class Necroxis : Form
    {
        public Point mouseLocation = new Point();
        public Timer time = new Timer();
        public Necroxis()
        {
            InitializeComponent();

            time.Tick += Tick;
            time.Start();

            ForlornApi.Api.InitializeForlorn();
        }

        private void Tick(object sender, EventArgs e)
        {
            if (ForlornApi.Api.IsRobloxOpen() == true)
            {
                label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(2)))));
            }
            else
            {
                label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(2)))), ((int)(((byte)(2)))));
            }
            if (ForlornApi.Api.IsInjected() == true)
            {
                label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(255)))), ((int)(((byte)(2)))));
            }
            else
            {
                label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(2)))), ((int)(((byte)(2)))));
            }
        }
        private void MouseDowned(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }
        private void MouseMoved(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FastColoredTextBox1_Load(object sender, EventArgs e)
        {
            fastColoredTextBox1.Language = FastColoredTextBoxNS.Language.Lua;
        }
        private void Button9_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Visible = false;
            button11.Visible = false;
            button10.Visible = false;
            button8.Visible = false;
            button4.Visible = false;
            button3.Visible = false;
            panel7.Visible = false;
            label4.Visible = false;
            label6.Visible = false;
            panel4.Visible = false;
            panel4.Visible = false;
            label5.Visible = false;
            label3.Visible = false;
        }

        private void Label4_Click(object sender, EventArgs e)
        {
            if (this.label6.ForeColor == System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(2)))), ((int)(((byte)(2))))))
            {
                this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(255)))), ((int)(((byte)(2)))));
                ForlornApi.Api.SetAutoInject(true);
            }
            else
            {
                this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(2)))), ((int)(((byte)(2)))));
                ForlornApi.Api.SetAutoInject(false);
            }
        }

        private void Label3_Click(object sender, EventArgs e)
        {
            if (ForlornApi.Api.IsRobloxOpen() == true)
            {
                ForlornApi.Api.KillRoblox();
            }
            else
            {
                MessageBox.Show("Client Is Not Opened!", "Necroxis");
            }
        }

        private void Label7_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel7.Visible = false;
            label4.Visible = false;
            label6.Visible = false;
            panel4.Visible = false;
            label5.Visible = false;
            label3.Visible = false;
            fastColoredTextBox1.Visible = true;
            button11.Visible = true;
            button10.Visible = true;
            button8.Visible = true;
            button4.Visible = true;
            button3.Visible = true;
        }

        private void Label8_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Visible = false;
            button11.Visible = false;
            button10.Visible = false;
            button8.Visible = false;
            button4.Visible = false;
            button3.Visible = false;
            panel3.Visible = true;
            panel7.Visible = true;
            label4.Visible = true;
            label6.Visible = true;
            panel4.Visible = true;
            label5.Visible = true;
            label3.Visible = true;
        }

        private void Label10_Click(object sender, EventArgs e)
        {
            if (ForlornApi.Api.IsInjected() == false)
            {
                if (ForlornApi.Api.IsRobloxOpen() == true)
                {
                    MessageBox.Show("Injecting...", "Necroxis");
                    ForlornApi.Api.Inject();
                }
                else
                {
                    MessageBox.Show("Client IS Not Opened!", "Necroxis");
                }
            }
            else
            {
                MessageBox.Show("Already Injcted!", "Necroxis");
            }
        }

        private void Label11_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = string.Empty;
        }

        private void Label12_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (Stream s = File.Open(saveFileDialog1.FileName, FileMode.CreateNew))
                using (StreamWriter sw = new StreamWriter(s))
                {
                    sw.Write(fastColoredTextBox1.Text);
                }
            }
        }

        private void Label13_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filename = openFileDialog1.FileName;
                string readfile = File.ReadAllText(filename);
                fastColoredTextBox1.Text = readfile;
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if (ForlornApi.Api.IsRobloxOpen())
            {
                if (ForlornApi.Api.IsInjected())
                {
                    ForlornApi.Api.ExecuteScript(fastColoredTextBox1.Text);
                }
                else
                {
                    MessageBox.Show("Exploit Is Not Injected!", "Necroxis");
                }
            }
            else
            {
                MessageBox.Show("Client IS Not Opened!", "Necroxis");
            }
        }
    }
}